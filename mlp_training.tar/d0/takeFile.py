#!/usr/bin/python2.7
import os

with os.popen('echo sample*') as f:
    fileList = f.readline().split()

for fileName in fileList:
    os.system('cp ./%s/%s ./'%(fileName,fileName + '.out'))
