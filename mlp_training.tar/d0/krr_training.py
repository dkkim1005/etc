#!/usr/bin/python2.7
import numpy as np
from sklearn.kernel_ridge import KernelRidge
from sklearn.grid_search import GridSearchCV
import cPickle


class KRR_Generator:
    def __init__(self, alpha_range, gamma_range, K=5):
        self.alpha_range = np.array(alpha_range)
        self.gamma_range = np.array(gamma_range)
        self.grid = GridSearchCV(KernelRidge(kernel='rbf',gamma=0.1), param_grid=dict(gamma=gamma_range,alpha=alpha_range), cv=K)
        self.inData = []
        self.outData = []
        self.numTail = -1

    def insert_data(self, inData, outData):
        size_col = len(inData)

        assert(size_col == len(outData))

        for i in xrange(size_col):
            self.inData.append([])
            self.outData.append([])
            self.numTail += 1

            for j,datum in enumerate(inData[i]):
                self.inData[self.numTail].append(datum)

            for j,datum in enumerate(outData[i]):
                self.outData[self.numTail].append(datum)

    def run(self):
        self.grid.fit(self.inData,self.outData)
        print "The best parameters are %s with a score of %0.2f"% (self.grid.best_params_,self.grid.best_score_)

    def predict(self,x):
        result = self.grid.predict(x)[0]
        return result

    def saveObj(self,nameFile):
        with open(nameFile,'wb') as f:
            cPickle.dump(self.grid,f)


if __name__ == '__main__':
    import sys
    import os

    numNeuron = 57
    with os.popen('echo *.out') as f:
        fileList = f.readline().split()

    try:
        degree = int(sys.argv[1])
        nameMachine = 'machine.out'
        if(len(sys.argv) == 3):
            nameMachine = sys.argv[2]
            os.chdir(path)
            if(len(sys.argv) == 4):
                path = sys.argv[3]
    except:
        print "* Error! *"
        print "argv[1]: degree(integer only)."
        print "argv[2]: name for a trained machine(default: 'machine.out')."
        print "argv[3]: directory path(default: current position)."
        print "check the input options... sorry"
        exit()


    def genInputData(fileName, degree, numNeuron=57):
        with open(fileName) as f: numCol = len(f.readlines())
        x = np.zeros([numCol,2])
        y = np.zeros([numCol,numNeuron])
        with open(fileName) as f: 
            for i in xrange(numCol):
                line = f.readline().split()
                time = float(line[0])
                x[i,:] = [time, degree]
                y[i,:] = np.array(line[1:],dtype='float64')

        return x,y


    alpha_range = [1e0, 0.1, 1e-2, 1e-3]
    gamma_range = np.logspace(-2,2,30)

    reg = KRR_Generator(alpha_range,gamma_range,K=len(fileList)-1)

    #for fileName in fileList:
    x,y = genInputData(fileList[0],degree,numNeuron=numNeuron)
    reg.insert_data(x,y)

    print 'we successfully completed to read all data.'
    print 'input :', len(reg.inData),'X','2'
    print 'output:', len(reg.outData),'X','%d'%numNeuron,'\n'

    print 'now machine is training...'
    reg.run()

    print 'complete!'

    #reg.saveObj(nameMachine)

    """
    with open('test_sample.out','w') as f:
        for i in xrange(len(x)):
            f.write('%f '%x[i,0])
            for j in xrange(len(y[i])):
                f.write('%f '%reg.predict(x[i])[j])
            f.write('\n')
    """
